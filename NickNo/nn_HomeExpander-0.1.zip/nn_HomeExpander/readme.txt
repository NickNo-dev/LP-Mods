Home Expander (LifePlay) ReadMe, Change Log and TODO List
========================================================

ReadMe
********

This mod extends your home with multiple rooms.

Known problems
~~~~~~~~~~~~~~

The original "Go to bathroom" is hard wired into the game.

If you want to get rid of it, open the file 
'LifePlay\Content\Modules\vin_Base\Actions\basicneeds\go_to_the_bathroom.lpaction'
with your text editor and remove the "home, " from the WHERE line, keeping the rest.

Change Log
************

Version 0.1 (28.12.2020):
- Initial release based on F95 idea https://f95zone.to/threads/lifeplay-v3-17-vinfamy.11321/post-4808049


TODOs (Planned features by NickNo)
************************************
Developer
- Rooms should be empty and furniture should be buyable
- Make people live in rooms
- Add special interactions to the NPCs / rooms

PRIO 1

PRIO 2

PRIO 3

Feature Requests (Requested by others)
****************************************
LifePlay Patrons will be served first!

REQEST: Example request
FROM: NickNo (Discord)


Developer & Tester Notes
**************************
