NickNo's HomeExtensions (LifePlay) ReadMe, Change Log and TODO List
===================================================================

ReadMe
********

HomeExtensions (HE) allows you to add more rooms and life to your home.

Before you are able to use a room you need to build it. Select "Build a new room (HE)" when at home to do so.
When building a room you can choose between DIY (if you got enough energy, fitness etc.) or hire workers to do the job for you.

It will take between 6-10 hours to build the room, depending on your choice.

If you go for the DIY route its cheaper, takes longer but you gain some fitness, intelligence, muscle etc - if you let the workers do it, its more expensive but faster.

If you constructed a second and/or third bedroom you can rent it to earn some money... Or do lewd things with your tenants. ;-)

Renting rooms to others
~~~~~~~~~~~~~~~~~~~~~~~
The bedrooms 2+3 can be let to others.
Just select "Manage rented rooms (HE)" from the home menu.

If you want someone from your contacts to move in
- the person must not be married
- the person must like you (rapportwithplayer > -10)
- Chances are better if the person is dating you

If you put the rooms on advertising anybody may move in.

To collect your rent use the action "Collect rental fee (HE)" action.
This is available weekly. (Or in larger intervalls.)

Tenants may also move out randomly!

Lewd scenes and how they work
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
There are several lewd scenes that either trigger randomly or by doing certain actions:
- Go to the bathroom
- Go to a rented room (WIP)
- Go to the Kitchen (WIP)
- Be in your office (WIP)
- Be alone and in your home

These scenes lead to different outcomes depending on the rapport the actor has with you as well as its
- perversion
- arousal
- masochist stat

If perversion and arousal are high you have the chance to encounter a sex scene, also if the person is submissive enough.

Rapport, Perversion and Arousal stats will raise by regularily by checking on the tenants wherever they are.
(Rapport may also decrease if you disturb Tenants too often!)

Known problems
~~~~~~~~~~~~~~

Tenants are not visible if idle
-------------------------------

This is currently not solvable. 
I hope Vinfamy comes up with a solution.

Currently only dogs and companions are visible.

Random (non HE) scenes seem to hang
------------------------------------

This happens in the rare moment when a Home Expander scene is running and the game engine decides to trigger a random event that needs the sceneUI.

Workaround: Click the red "Emergency" text in the bottom right corner to exit the random scene.


I see two "Go to the bathroom" actions
--------------------------------------

The original "Go to bathroom" is hard wired into the game.

If you want to get rid of it, open the file 
'LifePlay\Content\Modules\vin_Base\Actions\basicneeds\go_to_the_bathroom.lpaction'
with your text editor and remove the "home, " from the WHERE line, keeping the rest.


Sometimes the "Manage rented rooms" action shows no tenants
-----------------------------------------------------------
Yep, I can confirm this. But yet I do not know how to solve it.
I think I found a "dirty" workaround and implemented it.

If it still happens please close and reopen the menu.

Change Log
************

Version 0.3 (30.12.2020):
- Added option to let bedroom 2+3 to tenants
- Added scene for random tenant applications
- Added scene where tenant moves out due to random circumstances...
- Added scene for random bathroom events (if alone, can also be triggered manually by going to the bathroom)
- Bathroom party quest added
- Added scene to meet one or both tenants in the kitchen (WIP)
- Added scene to meet one or both tenants in their rooms (WIP)
- Bedroom 2+3 redesigned to fit their purpose better...
- Fix: Collect rent will now work properly on first try. (It paid out a little too much :))
- Name of the mod changed to "HomeExtensions"

Version 0.2 (28.12.2020):
- Rooms (other than bathroom) now need to be unlocked by building them (see readme)
- 3rd bedroom added
- Kitchen added
- Other 3D rooms enhanced, spawn point for player set
- All rooms have doors now... ^_^
- If Player has a dog it will show up randomly in rooms
- Ability to rent bedroom 2+3 added
    -> Currently tenants do not show up. Need to discuss this with Vinfamy.
    -> This is not a bug in the mod or the game. I bet I am using the modding API in a way Vinfamy did not plan it ... yet. :D
- Rent can be collected weekly (or at larger intervalls but no less than 7 days)


Version 0.1 (28.12.2020):
- Initial release based on F95 idea https://f95zone.to/threads/lifeplay-v3-17-vinfamy.11321/post-4808049


TODOs (Planned features by NickNo)
************************************
Developer
- Add special interactions to the NPCs / rooms
- Add bathroom used + "peek" into it
- Add scene where NPC cannot pay rent and needs to do other services
- Add spy cams
- Let tenants have intercourse or hate e/o
- Add more quests
- Use intoxication for certain events

PRIO 1

PRIO 2

PRIO 3
- Also rent rooms to submissive ppl

Feature Requests (Requested by others)
****************************************
LifePlay Patrons will be served first!

REQEST: Example request
FROM: NickNo (Discord)


Developer & Tester Notes
**************************

You can call the debug menu using the following #-key command: nn_he_debug
In this menu you can 
- enable all rooms
- disable all rooms
- kick all tenants out
