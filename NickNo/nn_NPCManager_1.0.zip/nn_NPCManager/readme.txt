NPC Manager ReadMe, Change Log and TODO List
=============================================

ReadMe
********
Thanks for downloading the NPC manager.
This little tool can help you setting relationships between NPCs or the player and its relatives.

You can find the manager in the "PC" menu, if the mod is enabled.

Please ensure to use the NPC / relative as "target1".


Change Log
************

Version 1.0 (19.12.2020):
- First public release

TODOs (Planned features by NickNo)
************************************
- Support adding new relatives to the player

Feature Requests (Requested by others)
****************************************

Developer & Tester Notes
**************************
