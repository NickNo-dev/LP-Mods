Porn Empire (LifePlay) ReadMe, Change Log and TODO List
========================================================

ReadMe
********

Porn Empire is a LifePlay mod (add-on) that allows you to run your own 
porn business in LifePlay. You start at a very low level taking pictures 
and videos with your smart phone of your sex workers and your perverted dates.
Over time your business grows and you can buy more equipment and employ 
workers that will assist you in your daily tasks.

LifePlay version 2.16 or later is required for Porn Empire to work correctly!


Earning money in PornEmpire
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Money can be earned by launching a website and putting videos online. 
Videos will be downloaded by your visitors as soon as you release them and 
they will pay money for that.
* If you have famous models you will get more visitors.
* Model fame grows with an increasing download count.
* If you get better equipment you will get more valuable videos.
* The older a video gets the more its value drops.

Money is currently earned by launching the "Check business performance" 
action in the sex work tab.


Getting videos
~~~~~~~~~~~~~~

Just launch the action "Organize a shooting" from the sex work tab. 
If you have a companion the companion will be asked to take part in the 
session otherwise you can choose one of your contacts.

If the chosen model is not a sex worker or not perverted enough he/she will 
decline. Try your luck to convince him/her if his/her masochist stat is low 
enough.

Every model will ask for money. You may try to negotiate as well.

You have different shooting options to chose from. Just try them out. NOW!

By the way, if you convinced someone to become a model the tag "PEModel" 
will be added to this contact.


Uploading stuff
~~~~~~~~~~~~~~~

If you managed to launch your website (action "Launch a porn website" in the 
"Manage business" menu) you can upload previously created videos to it. 

You should do that right after doing some shoots as nobody will be able to see 
your new work if you do not upload it.

A web admin could do that task for you and improve the quality of the uploaded 
content but will cost some money.


Porn fame in PornEmpire
~~~~~~~~~~~~~~~~~~~~~~~

The porn fame of a model affects the amount of money you earn with him/her. 
Videos of famous models keep the interest in them high for a longer time. 

So a shooting with a famous model costs more money, but the results will be 
better and the demand for them will last longer.

Additionally the models attractiveness affects the value of her/his work. 
... and of course the price ;-)

If a models fame changes after doing a shoot this will also affect the 
value of the footage.

The porn fame of a cam operator affects the quality (and therefore price) 
of the shooting results. A famous CamOp' is also more expensive to hire.


Porn genres in PornEmpire
~~~~~~~~~~~~~~~~~~~~~~~~~

There are the following distinct genres in Porn empire: Amateur, Solo, 
Lesbian and Gay. Your visitors will request all of these genres to be 
available on your website. If you do not satisfy the need you will loose 
visitors. You should keep at least 2/4 of these genres updated regularly.

How to get these genres? Lesbian and gay should be easy to think off. 
Just let two models of the same sex do a shooting. Only problem is: Not 
all models are bisexual... ;-)

Solo is easy as well. Only one model (f/m/t) must perform.

Amateur requires at least one model of the shooting to have a porn fame 
below 25%. As the fame increases with time (if you uploaded stuff of a model) 
you occasionally have to find new amateurs.

To know what is demanded by your visitors use the 'Manage your business' menu.
To know in which shootings a model did participate use the 'Manage employees' 
menu.


Known problems
~~~~~~~~~~~~~~

If you DELETE a model from your contact list (blocking is OK) you will 
loose all shootings associated to it. This is currently not fixable.

You cannot hire relatives as employees (cam operator, scene assistant, web admin).


Change Log
************

Version 0.1 Beta (21.01.2020):
- Model agency added with 20 female high class models
- Model agency can be hired to search for new models with customized character generator
- Amateur, solo, 1-on-1, threesome and gang-bang as well as lesbian and gay shootings added (will be auto detected as soon as you do a shooting)
- Scene Assistant and cam operator can now join after a shooting (if enough space)
- Interest in amateur, solo, lesbian and gay gang bang stuff increases with growing number of uploaded content
- If the interest is not satisfied visitors will leave. So keep at least 3/4 of interest high!
- Model statistics added (see manage employees menu) -> Only work for new shootings
- Inventory added (see manage business menu) -> Only works for shootings Beta 0.1 and up!
- Web cam models can be fired now
- Web cam model training respects incest settings now
- Incest enabled if vin_Incest module is active
- Perversion and arousal are used now (perversion >55 makes contacts become models, arousal >65 triggers after work sex)
- Included Vima's hotel room preset

Internal fixes:
- Shooting scene reworked
- AllModelsAreBi setting works now

Version 0.05 Alpha (13.01.2020):
- Settings menu reworked
- Manage business menu added
- Game now respects models sexual interest (gender)
- Player can't do 1-on-1 shootings with relatives any more (but with other models and relatives)
- You can now select a location before doing a shooting (hotel, bed room, office, ...)
- Added one office and 3 hotel room presets
- You can now rent an office to store more equipment and do shootings in it
- Added "the PornAgency" for hiring models (costs more, agency boss etc.)

Version 0.04 Alpha (10.01.2020):
- You can watch and join cam shows
- Web cam models and employees will ask for salary increases randomly
- Random job applications as web cam model with random generated actors
- You can now book advertising campaigns in addition to the existing monthly advertising contracts
- Player and photographer will get horny (perverted) if they only have a passive role in a shooting
- If you are horny (perverted) enough you can join your models after shootings for some private fun
- If your photographer is horny (perverted) enough he/she can join after a 1-on-1 shooting with the player
- Job trainings added, can only be done once a week per employee
- Salary negotiations can only be done once a month
- Web camming now uses correct timing (weekly)
- Web camming balance algorithms reworked
- Scenes to hire and manage employees were consolidated and refactored, so they can be used for any employee type
- You can now hire scene assistants and cam operators (both for video shootings)
- Advertising menu reworked and uses new timing methods
- Debug menu extended
-> If you played a previous ALPHA version you may want to use the debug menu to DELTE ALL SETS...

Version 0.03 Alpha (04.01.2020):
- Business report now works with correct timing. You can trigger the action only once a day. The report will summarize if more then one day elapsed.
- You will loose visitors if you have only old photo sets on your website
- Management of employees added 
- Added photographer, the higher his/her porn fame is, the better shootings will be promoted
- Added web administrator. The admin will upload new stuff automatically. The higher his/her intelligence is, the better shootings will be made.
- Added staff training option
- Joining shootings is no more possible without having a photographer (you cant take perfect photos while fucking - right?)
- Bug fixed that prevented actions from triggering although you clicked them
- Actions now have energy conditions (if your energy is too low you cannot start them)
- Some actions now need to be trigged at a certain daytime (eg. doing shoots from 8AM till night)

Version 0.02 Alpha (02.01.2020):
- Added web cams incl. management of models
- Shootings + camming now costs money (sex workers get less)
- Changed the way visitors come to your website (no more random)
- Option to ask contacts to join shootings
- Option to add agency models to your contacts after first shooting
- Changed the way you buy equipment (step by step)
- Added more random dialogue items
- Reworked the algorithms in the business report (income calculations)

Version 0.01 Alpha (31.12.2019):
- Initial release


TODOs (Planned features by NickNo)
************************************
Developer
- Prevent adding the same PA Premium model several times
- Calculate correct price for premium models in 2nd stage


PRIO 1
- Add more shooting genres (art-porn, 3-some, gang-bang, rev. gang-bang)
- Change perversion to arousal
- Add correct perversion

PRIO 2
- Add "super models" (very high stats...)

PRIO 3
- Reduce price if you ask one of you partners to do a shooting and you are short on money
- Do something useful with the office size...
- Add some sort of competitors
- Add "Merchandise" to equipment
- Add events that massively increase / decrease visitor count
- ACTION: Allow player to adjust pe_PhotoSetPrice (fixed at 2,5$) and pe_WebCamShowPrice (5$)
  -> Reduce visitor count if requested price is too high for model & site fame
- Add unique texts to nn_pe_scene_ask_to_become_web_cam_model.lpscene

Feature Requests (Requested by others)
****************************************

LifePlay Patrons will be served first!

REQEST: Example request
FROM: NickNo (Discord)


Developer & Tester Notes
**************************

To open the debug menu press the # key and type:
nn_pe_debug + return
