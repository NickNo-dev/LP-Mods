NPC Manager ReadMe, Change Log and TODO List
=============================================

ReadMe
********
Thanks for downloading the NPC manager! Read this or be doomed!

What is this?
~~~~~~~~~~~~~

This little tool can help you to
- Set relationships between NPCs, relatives and/or the player (MC)
- Find 'lost' NPCs and add them to your contacts
- Delete all NPCs not in your contacts (To increase game performance)
- Delete ALL NPCs (even your contacts)
- Delete ALL Relatives

Usage
~~~~~

You can find the manager in the "PC" menu, if the mod is enabled.
For most actions you need to specify at least one NPC target. (Usally target1)
The second target slot will automatically set to the player, but you may
change this.

Please ensure to always use Player as "target2".
This tool does not contain any sanity checks. So if you set inapropriate 
targets and your game breaks... good work!

Find by Name
~~~~~~~~~~~~

The find by name function can look for a specific NPC by its name.
The name must be correctly spelled. The search is case insensitive.
If you do not know the name you may use * as a placeholder. 
The NPC Manager will then list each NPC it finds.

WARNING
~~~~~~~

None of the changes the NPC Manager does can be undone.
So... guess what: Save before using it!

Some tasks run a little longer, depending on the amount of NPCs 
in your savegame and your computers performance.

F A Q
~~~~~

Q: How do I know how many NPCs are in the game but not my contacts?
A: Save your game. Then "DELTE ALL NPCs (except contacts)". This will give you a number. -> Load your game!

Change Log
************

Version 1.1 (22.12.2020):
- Added option to delete ALL NPCs from game
- Fix: Menu was not working correctly

Version 1.0 (19.12.2020):
- First public release

TODOs (Planned features by NickNo)
************************************
- Support adding new relatives to the player

Feature Requests (Requested by others)
****************************************

Developer & Tester Notes
**************************
